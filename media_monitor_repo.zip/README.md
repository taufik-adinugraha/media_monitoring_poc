# Media Monitoring Repo (Metadata Lake + LLM Enrichment + Sonar Deep Analytics)

This repository implements a **metadata-first media monitoring pipeline**:

- **Ingest (periodic):**
  - GDELT Doc API (news discovery)
  - MediaStack (aggregated news API)
  - Publisher RSS feeds (ground-truth, source-cited)
  - YouTube channel RSS (social / broadcast signals)
- **Preprocess/enrich (periodic):**
  - Normalize fields to a common schema
  - De-duplicate by URL fingerprint
  - LLM enrichment using **Gemini** (cheap small model) to produce structured tags:
    - topics, actors, locations, language, is_editorial
- **Store:**
  - SQLite via SQLAlchemy (portable; swap DB by changing `DATABASE_URL`)
- **Deep analytics (on-demand):**
  - Select relevant URLs from the DB
  - Run **Sonar** (Perplexity) to generate a narrative report for a dashboard

## Why metadata-first?

- Cheap and scalable to ingest frequently
- Clear provenance: you always keep the original URLs
- Deep reading is expensive -> do it **only on demand** (Sonar)

---

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

Copy env template:

```bash
cp .env.example .env
# then edit values (keys, DB url, etc.)
```

### 1) Run one cycle (ingest + store + enrich)

```bash
python scripts/run_once.py --config monitor_config.json
```

### 2) Run as a periodic worker

```bash
python scripts/run_worker.py --config monitor_config.json --interval-min 30
```

### 3) Generate deep analytics report (Sonar)

```bash
python scripts/generate_report.py --config monitor_config.json --since-days 7
```

Output:
- `reports/report_latest.md`
- `reports/report_<timestamp>.md`

---

## Configuration (`monitor_config.json`)

- `sources.*.enabled`: turn sources on/off
- `taxonomy.topics`: customizable topics (keywords + optional locations hints)
- `taxonomy.actors`: list of actors you care about
- `preprocess.gemini_model`: default Gemini model to use
- `report.sonar_model`: default Sonar model to use

**Note on MediaStack languages**
MediaStack supports a limited language list (e.g., en, fr, de, etc.). Indonesian (`id`) is typically not in the supported list.
In this repo, `languages` is optional and validated — if you set an unsupported language code, it will be dropped with a warning.

---

## Data model (DB)

Each record stores:
- `platform`: gdelt | mediastack | rss | youtube
- `source_type`: news | social
- `publisher_or_author`
- `url`, `title`, `summary`
- `published_at`, `ingested_at`
- `tags_json` (topics/actors/locations/language/is_editorial)
- `raw_json` (original payload)

SQLite is used by default, but you can point `DATABASE_URL` at Postgres later:
```bash
export DATABASE_URL="postgresql+psycopg://user:pass@host:5432/dbname"
```

---

## Repo layout

```text
media_monitor_repo/
├─ media_monitor/
│  ├─ settings.py
│  ├─ config.py
│  ├─ utils.py
│  ├─ pipeline.py
│  ├─ db/
│  │  ├─ models.py
│  │  └─ store.py
│  ├─ sources/
│  │  ├─ gdelt.py
│  │  ├─ mediastack.py
│  │  ├─ rss.py
│  │  └─ youtube.py
│  ├─ preprocess/
│  │  ├─ schema.py
│  │  ├─ gemini_client.py
│  │  └─ enrich.py
│  └─ analytics/
│     ├─ sonar_client.py
│     └─ report.py
├─ scripts/
│  ├─ run_once.py
│  ├─ run_worker.py
│  ├─ generate_report.py
│  └─ list_mediastack_sources.py
├─ tests/fixtures/
│  ├─ gdelt_sample.json
│  ├─ mediastack_sample.json
│  ├─ rss_sample.json
│  └─ youtube_sample.json
├─ monitor_config.json
├─ requirements.txt
├─ .env.example
└─ README.md
```

---

## Offline smoke test

This repo includes fixtures so you can validate the pipeline without any API keys:

```bash
python scripts/run_once.py --config monitor_config.json --offline-fixtures
```

This will ingest from `tests/fixtures/*` instead of calling external APIs.

---

## Notes / operational tips

- **GDELT**: great for discovery, but often returns URL + metadata, not full content.
- **RSS**: best for provenance and stability; but can be flaky and should degrade gracefully.
- **YouTube**: channel RSS is stable; stats require YouTube Data API.
- **Gemini enrichment**: store only structured tags; avoid storing full copyrighted text.
- **Sonar deep report**: run it on-demand for a dashboard query; keep the prompt scoped to selected URLs.
